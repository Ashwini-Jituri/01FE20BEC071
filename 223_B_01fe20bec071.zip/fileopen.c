#include <stdio.h>
#include <stdlib.h>
void main()
{
FILE *p;
char ch;
p=fopen("I:store.txt","w");
fprintf(p,"This is a c code");

fclose(p);

}
