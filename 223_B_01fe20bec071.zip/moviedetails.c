//movie deatails
#include <stdio.h>
#include <stdlib.h>

struct movie_details
{ char name[25],pro[25],dir[25],phouse[25];
int yr;
};


typedef struct movie_details MD;
void read(MD[], int);
void sort_yr(MD x[],int);
void disp_dr(MD x[],int);
void disp_ph(MD x[],int);


void main()
{MD x[10];
int n;
printf("enter no of movies\n");
scanf("%d",&n);
read(x,n);
sort_yr(x,n);
disp_dr(x,n);
disp_ph (x,n);

}
void read(MD x[10],int n)
{int i;
printf("Enter movie details\n\n");
for(i=0;i<n;i++)
{printf("Enter movie name:");
scanf("%s",x[i].name);
printf("enter producer name:");
scanf("%s",x[i].pro);
printf("Enter director name:");
scanf("%s",x[i].dir);
printf("Enter year:");
scanf("%d",&x[i].yr);
printf("Enter pro house name:");
scanf("%s",x[i].phouse);

}
}
void sort_yr(MD x[10],int n)
{int i,j;
MD swap;
for(i=0;i<n-1;i++)
{for(j=0;j<n-i-1;j++)
{if (x[j].yr>x[j+1].yr)
{swap=x[j];
x[j]=x[j+1];
x[j+1]=swap;}
}
}
}
void disp_dr(MD x[10],int n)
{int i;
char D;
printf ("Enter director name\n");
scanf("%s",D);
if(D==x[i].dir)
{
printf(" movie details\n\n");
for(i=0;i<n;i++)
{printf(" movie name:");
printf("%s",x[i].name);
printf("producer name:");
printf("%s",x[i].pro);
printf(" director name:");
printf("%s",x[i].dir);
printf("year:");
printf("%d",x[i].yr);
printf("pro house name:");
printf("%s",x[i].phouse);

}
}
}
void disp_ph(MD x[10],int n)
{int i;
char P[25];
printf ("Enter director name\n");
scanf("%s",P);
if(P[]==x[i].phouse)
{
printf(" movie details\n\n");
for(i=0;i<n;i++)
{printf(" movie name:");
printf("%s",x[i].name);
printf("producer name:");
printf("%s",x[i].pro);
printf(" director name:");
printf("%s",x[i].dir);
printf("year:");
printf("%d",x[i].yr);
printf("pro house name:");
printf("%s",x[i].phouse);

}
}
}
