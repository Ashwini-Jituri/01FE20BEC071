//details of student using array
#include <stdio.h>
#include <string.h>
struct student
{int id;
char name[10];
float p;
};
typedef struct student s;
void read(s r[],int);
void display(s r[],int);
void main()
{ int n;
s r[100];
scanf("%d",&n);
read(r,n);
display(r,n);
}

void read(s r[],int n)
{int j;

for(j=0;j<n;j++)
{scanf("%d%s%f",&r[j].id,r[j].name,&r[j].p);

}
}
void display(s r[],int n)
{int j;

for(j=0;j<n;j++)
{printf("\n\n%d\n%s\n%f\n",r[j].id,r[j].name,r[j].p);
}
}
