// student deatails in files
#include <stdio.h>
#include <string.h>
struct student
{int id;
char name[10];
float p;
};
typedef struct student s;
void read(s *r,int);
void display(s *r,int);
void main()
{ int n;
s  r[100],*r1;
r1=r;
scanf("%d",&n);
read(r1,n);
display(r1,n);
}

void read(s *r1,int n)
{int j;

for(j=0;j<n;j++)
{scanf("%d%s%f",&r1->id,r1->name,&r1->p);
r1++;
}

}
void display(s *r1,int n)
{int j;

for(j=0;j<n;j++)
{printf("\n\n%d\n%s\n%f\n",r1->id,r1->name,r1->p);
r1++;
}

}
