//structure using malloc
#include <stdio.h>
#include <string.h>
struct student
{int id;
char name[10];
float p;
};
typedef struct student s;
void read(s *r);
void display(s *r);
void main()
{ int n;
s  *r1;
r1=(s*)malloc(15*sizeof(s));
read(r1);
display(r1);
}

void read(s *r1)
{int j;

for(j=0;j<15;j++)
{scanf("%d%s%f",&r1->id,r1->name,&r1->p);
r1++;
}

}
void display(s *r1)
{int j;

for(j=0;j<15;j++)
{printf("\n\n%d\n%s\n%f\n",r1->id,r1->name,r1->p);
r1++;
}

}
